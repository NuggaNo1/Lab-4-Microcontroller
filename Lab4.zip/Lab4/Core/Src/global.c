/*
 * global.c
 *
 *  Created on: Nov 26, 2024
 *      Author: PC
 */


#include "global.h"

uint32_t timestamp = 0;
