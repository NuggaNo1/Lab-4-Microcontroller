/*
 * scheduler.c
 *
 *  Created on: Nov 26, 2024
 *      Author: PC
 */


#include "scheduler.h"
#include "main.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

TaskList_t TaskList;
uint32_t TaskIDCounter = 0; // we using ID as invalid ID

ERROR_CODE ErrorCode = NO_ERROR;
ERROR_CODE LastErrorCode = NO_ERROR;

char str[50];

void schedulerInit(){
	TaskList.head = NULL;
	TaskList.size = 0;
}

void schedulerUpdate(){
	timestamp+=10;
	if(TaskList.size && TaskList.head -> Delay > 0) TaskList.head -> Delay--;
}

int deleteTask(uint32_t ID){
    if(TaskList.size == 0)
        // The list is empty, invalid operation
        return 1;

    TaskControlBlock_t * curr = TaskList.head;
    TaskControlBlock_t * prev = NULL;

    while(curr != NULL){
        if(ID == curr -> TaskID){
            if(prev == NULL && curr -> NextTask == NULL){
                free(curr);
                TaskList.head = NULL;
                TaskList.size--;
				curr = NULL;
            } else if (prev == NULL){
                curr -> NextTask -> Delay += curr -> Delay;
                TaskList.head = curr -> NextTask;
                free(curr);
                TaskList.size--;
				curr = NULL;
            } else if (curr -> NextTask == NULL){
                free(curr);
                prev -> NextTask = NULL;
                TaskList.size--;
				curr = NULL;
            } else {
                curr -> NextTask -> Delay += curr -> Delay;
                prev -> NextTask = curr -> NextTask;
                curr -> NextTask = NULL;
                free(curr);
                TaskList.size--;
				curr = NULL;
            }

        } else {
            prev = curr;
            curr = curr -> NextTask;
        }
    }
    return 0;
}

RETURN_CODE schedulerDeleteTask(const unsigned char TaskID){
	RETURN_CODE returnCode;
	if(deleteTask(TaskID))
		returnCode = ERROR_SCH_CANNOT_DELETE_TASK;
	else
		returnCode = NO_ERROR;
	return returnCode;
}

int addTask(TaskControlBlock_t * task){
    if(TaskList.size >= SCH_MAX_TASKS)
        return 1;
    if(TaskList.size == 0){
        TaskList.head = task;
        TaskList.size++;
        return 0;
    }

    TaskControlBlock_t * curr = TaskList.head;
    TaskControlBlock_t * prev = NULL;
    int found = 0;
    while(!found){
        if(curr != NULL && task-> Delay >= curr-> Delay){
            task -> Delay -= curr -> Delay;
            prev = curr;
            curr = curr -> NextTask;
        } else {
            task -> NextTask = curr;
            if(prev != NULL) prev -> NextTask = task;
            else TaskList.head = task;
            if(curr != NULL) curr -> Delay -= task -> Delay;
            TaskList.size++;
            found = 1;
        }
    }
    return 0;
}

unsigned char schedulerAddTask(void (*functionPointer)(), unsigned int DELAY, unsigned int PERIOD){
	TaskControlBlock_t * task = (TaskControlBlock_t *)malloc(sizeof(TaskControlBlock_t));
	task -> Delay 		= DELAY;
	task -> Period 		= PERIOD;
	task -> TaskID 		= (++TaskIDCounter)%256;
	task -> TaskPointer = functionPointer;
	task -> NextTask 	= NULL;

	addTask(task);

	return task -> TaskID;
}

void schedulerDispatcher(){
	while(TaskList.size != 0 &&TaskList.head -> Delay == 0){
		uint32_t time_point = timestamp;
		sprintf(str, "TaskID: %ld timeout at timestamp: %ld ms\r\n", TaskList.head -> TaskID, time_point);
		writeMessage(str);
		(*TaskList.head -> TaskPointer)();
		if(TaskList.head -> Period) schedulerAddTask(TaskList.head -> TaskPointer, TaskList.head -> Period, TaskList.head -> Period);
		schedulerDeleteTask(TaskList.head -> TaskID);
	}
	schedulerReportStatus();
}

int ErrorTickCount = 0;
void schedulerReportStatus(){
#ifdef REPORT_ERROR
	if(ErrorCode != LastErrorCode){
		LastErrorCode = ErrorCode;
		TaskID_ScreenControl = schedulerAddTask(updateLEDMatrix, 10, 1, NULLPTR);
		setMatrixErrorCode(ErrorCode);
		if(ErrorCode != 0){
			ErrorTickCount = 60000;
		} else {
			ErrorTickCount = 0;
		}
	} else {
		if(ErrorTickCount != 0){
			if(--ErrorTickCount == 0){
				ErrorCode = 0;
			}
		}
	}
#endif
};

void schedulerSleep(){

};

#ifdef WATCHDOG
//watchdog section
IWDG_HandleTypeDef hiwdg ;
static uint32_t counterForWatchdog = 0;
void MX_IWDG_Init(){
	hiwdg.Instance = IWDG;
	hiwdg.Init.Prescaler = IWDG_PRESCALER_32;
	hiwdg.Readload = 4095;
	if(HAL_IWDG_Init(&hiwdg) != HAL_OK) Error_Handler();
}

void watchDogRefresh(){
	HAL_IWDG_Refresh(&hiwdg);
}
unsigned char isWatchDogReset(){
	if(counterForWatchdog > 3) return 1;
	else return 0;
}
void watchdogCounting(){
	counterForWatchdog++;
}
void resetWatchdogCounting(){
	counterForWatchdog = 0;
}
#endif
